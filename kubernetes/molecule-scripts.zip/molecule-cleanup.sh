#!/bin/bash

#List lck

#Delete views/node.<worker not existing>.dat*
