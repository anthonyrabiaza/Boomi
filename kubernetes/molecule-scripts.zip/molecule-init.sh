#!/bin/bash
export hostname=`cat /proc/sys/kernel/hostname`
export nodename=$ATOM_LOCALHOSTID
echo "`date`: Starting $hostname ($AMC) on node $nodename with user `id`">> /var/boomi/molecule-init.log

sleep 10
while [ ! -f /home/boomi/start-atom.sh ]; do
  sleep 1;
done

echo "`date`: Boomi files presents and available on $hostname">> /var/boomi/molecule-init.log

echo "`date`: Creating temporary folders for $hostname ...">> /var/boomi/molecule-init.log
mkdir -p /tmp/boomi/tmp
mkdir -p /tmp/boomi/local
mkdir -p /tmp/boomi/data
/usr/bin/chown -R boomi:boomi /tmp/boomi/tmp
/usr/bin/chown -R boomi:boomi /tmp/boomi/local
/usr/bin/chown -R boomi:boomi /tmp/boomi/data
echo "`date`: Folders created for $hostname">> /var/boomi/molecule-init.log
