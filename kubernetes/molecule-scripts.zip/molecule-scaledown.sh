#!/bin/bash
export hostname=`cat /proc/sys/kernel/hostname`
export nodename=$ATOM_LOCALHOSTID
echo "`date`: Scaling down $hostname ($AMC) on node $nodename with user `id`">> /var/boomi/molecule-init.log
sh /home/boomi/scaledown.sh
