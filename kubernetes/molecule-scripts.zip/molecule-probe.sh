#!/bin/bash
export nbBoomiJava=`ps aux | grep java | grep boomi | wc -l`
if [ $nbBoomiJava -ge 1 ]
then
  echo "The Boomi instance was found"
  exit 0
else
  echo "The Boomi instance was not found" >&2
  exit 1
fi

